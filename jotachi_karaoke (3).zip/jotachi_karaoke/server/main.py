"""Servidor de separación de voz para JOTACHI KARAOKE (Demucs).

Uso:  uvicorn main:app --host 0.0.0.0 --port 8000
Variable opcional API_KEY: si se define, la app debe enviarla en X-API-Key.
Variable opcional WHISPER_MODEL (por defecto "small") para las letras con IA.

Endpoints:
  POST /jobs            -> separa voz/instrumental (Demucs)
  GET  /jobs/{id}       -> estado
  POST /lyrics          -> transcribe la letra con tiempos (faster-whisper)
  GET  /lyrics/{id}     -> estado + letra en formato LRC
"""
import os
import pathlib
import shutil
import subprocess
import sys
import threading
import uuid

from fastapi import BackgroundTasks, Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse

from lyrics_utils import group_words, to_lrc

BASE = pathlib.Path(os.environ.get("JOBS_DIR", "jobs"))
BASE.mkdir(parents=True, exist_ok=True)
API_KEY = os.environ.get("API_KEY", "")
JOBS: dict = {}
LYRICS: dict = {}
WHISPER_MODEL = os.environ.get("WHISPER_MODEL", "small")
_whisper = None
_use_cpu = False
_whisper_lock = threading.Lock()

app = FastAPI(title="Jotachi separation server")


def auth(x_api_key: str = Header(default="")):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="API key inválida")


def run_job(job_id: str, src: pathlib.Path):
    out = BASE / job_id / "out"
    try:
        JOBS[job_id].update(status="processing", progress=0.05)
        cmd = [sys.executable, "-m", "demucs", "--two-stems=vocals", "-o", str(out), str(src)]
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        inst = next(out.rglob("no_vocals.wav"))
        voc = next(out.rglob("vocals.wav"))
        shutil.copy(inst, BASE / job_id / "instrumental.wav")
        shutil.copy(voc, BASE / job_id / "vocals.wav")
        JOBS[job_id].update(status="done", progress=1.0)
    except subprocess.CalledProcessError as e:
        JOBS[job_id].update(status="failed", error=(e.stderr or str(e))[-500:])
    except Exception as e:  # noqa: BLE001
        JOBS[job_id].update(status="failed", error=str(e))


@app.get("/health")
def health(_: None = Depends(auth)):
    return {"ok": True}


@app.post("/jobs")
async def create_job(bg: BackgroundTasks, file: UploadFile = File(...), _: None = Depends(auth)):
    job_id = uuid.uuid4().hex
    folder = BASE / job_id
    folder.mkdir(parents=True)
    suffix = pathlib.Path(file.filename or "audio").suffix or ".mp3"
    src = folder / f"input{suffix}"
    with src.open("wb") as f:
        shutil.copyfileobj(file.file, f)
    JOBS[job_id] = {"status": "queued", "progress": 0.0}
    bg.add_task(run_job, job_id, src)
    return {"id": job_id}


@app.get("/jobs/{job_id}")
def job_status(job_id: str, _: None = Depends(auth)):
    if job_id not in JOBS:
        raise HTTPException(404, "No existe")
    return JOBS[job_id]


def _stem(job_id: str, name: str):
    p = BASE / job_id / f"{name}.wav"
    if job_id not in JOBS or not p.exists():
        raise HTTPException(404, "Aún no disponible")
    return FileResponse(p, media_type="audio/wav", filename=f"{name}.wav")


@app.get("/jobs/{job_id}/instrumental")
def instrumental(job_id: str, _: None = Depends(auth)):
    return _stem(job_id, "instrumental")


@app.get("/jobs/{job_id}/vocals")
def vocals(job_id: str, _: None = Depends(auth)):
    return _stem(job_id, "vocals")


# ---------------------------------------------------------------- letras (IA)

def _transcribe_words(path: str, language: str):
    """Devuelve (palabras[(ini, fin, texto)], idioma). Si la GPU falla, usa CPU."""
    global _whisper, _use_cpu
    with _whisper_lock:
        for attempt in range(2):
            try:
                if _whisper is None:
                    from faster_whisper import WhisperModel

                    kw = (dict(device="cpu", compute_type="int8") if _use_cpu
                          else dict(device="auto", compute_type="auto"))
                    _whisper = WhisperModel(WHISPER_MODEL, **kw)
                segs, info = _whisper.transcribe(
                    path,
                    language=language or None,
                    word_timestamps=True,
                    vad_filter=True,
                    beam_size=5,
                )
                words = []
                for sg in segs:
                    if sg.words:
                        words += [(w.start, w.end, w.word) for w in sg.words]
                    elif sg.text.strip():
                        words.append((sg.start, sg.end, " " + sg.text.strip()))
                return words, info.language
            except Exception:  # noqa: BLE001
                if attempt == 0 and not _use_cpu:
                    _use_cpu = True
                    _whisper = None
                    continue
                raise


def run_lyrics(lyr_id: str, src: pathlib.Path, language: str):
    try:
        LYRICS[lyr_id].update(status="processing")
        words, lang = _transcribe_words(str(src), language)
        lrc = to_lrc(group_words(words))
        LYRICS[lyr_id].update(status="done", lrc=lrc, language=lang)
    except Exception as e:  # noqa: BLE001
        LYRICS[lyr_id].update(status="failed", error=str(e)[-500:])


@app.post("/lyrics")
async def create_lyrics(
    bg: BackgroundTasks,
    file: UploadFile = File(...),
    language: str = "",
    _: None = Depends(auth),
):
    lyr_id = uuid.uuid4().hex
    folder = BASE / f"lyrics_{lyr_id}"
    folder.mkdir(parents=True)
    suffix = pathlib.Path(file.filename or "audio").suffix or ".wav"
    src = folder / f"input{suffix}"
    with src.open("wb") as f:
        shutil.copyfileobj(file.file, f)
    LYRICS[lyr_id] = {"status": "queued"}
    bg.add_task(run_lyrics, lyr_id, src, language.strip())
    return {"id": lyr_id}


@app.get("/lyrics/{lyr_id}")
def lyrics_status(lyr_id: str, _: None = Depends(auth)):
    if lyr_id not in LYRICS:
        raise HTTPException(404, "No existe")
    return LYRICS[lyr_id]
