"""Utilidades puras para convertir palabras con tiempos en una letra LRC."""


def group_words(words, max_words=7, max_gap=0.9):
    """words: lista de (inicio_s, fin_s, texto). Devuelve [(inicio_s, linea)]."""
    lines, cur = [], []
    for w in words:
        if cur and (len(cur) >= max_words or w[0] - cur[-1][1] > max_gap):
            lines.append(cur)
            cur = []
        cur.append(w)
    if cur:
        lines.append(cur)
    out = []
    for line in lines:
        text = "".join(t for _, _, t in line).strip()
        if text:
            out.append((line[0][0], text))
    return out


def to_lrc(lines):
    """lines: [(inicio_s, texto)] -> texto LRC '[mm:ss.xx]texto'."""
    res = []
    for start, text in lines:
        cs = int(round(max(start, 0) * 100))
        m, rem = divmod(cs, 6000)
        s, c = divmod(rem, 100)
        res.append(f"[{m:02d}:{s:02d}.{c:02d}]{text}")
    return "\n".join(res)
