# JOTACHI PROFESSIONAL KARAOKE (Flutter, Android)

## Estado real
| Función | Estado |
|---|---|
| Compilar el APK (GitHub Actions) | Funciona (versión 0.1); los cambios de la 0.2 se comprueban al compilar |
| Importar canciones del teléfono | Probado: abre y funciona la pantalla |
| Quitar la voz (Demucs) en un servidor | Escrito, **sin probar de punta a punta** |
| Quitar la voz dentro del teléfono (sin internet) | **No implementada** |
| Letra sincronizada desde LRCLIB (búsqueda automática, limpia nombres, elige por duración) | Escrito, **sin probar** |
| Letra con tiempos generada con IA (Whisper, sobre la pista de voz) | Escrito, **sin probar** |
| Ajuste manual de sincronía de la letra (±0,25 s) | Escrito, **sin probar** |
| Grabar la voz | Escrito, **sin probar** |
| Mezclar tu voz con el instrumental | No existe aún |

## Servidor de IA sin PC (Google Colab)
1. Sube `JOTACHI_Servidor.ipynb` a la raíz del repositorio.
2. Abre: https://colab.research.google.com/github/jhonatannh19-tech/JOTACHI-KARAOKE/blob/main/JOTACHI_Servidor.ipynb
3. Entorno de ejecución → **T4 GPU** → **Ejecutar todo**.
4. Copia la **URL** y la **clave** que aparecen al final en la app: Ajustes → Guardar y probar.

La URL cambia cada vez que se reinicia Colab. El servidor descarga el código de `jotachi_karaoke.zip` del repositorio.

## Servidor en un PC (alternativa)
```
cd server && pip install -r requirements.txt
API_KEY=mi_clave uvicorn main:app --host 0.0.0.0 --port 8000
```
Necesita `ffmpeg`. En CPU una canción tarda varios minutos.

## Generar el APK
El workflow de GitHub Actions extrae `jotachi_karaoke.zip`, aplica parches, compila y publica `app-release.apk` como artefacto. El APK usa la firma de depuración: sirve para instalar y probar, no para Play Store.
