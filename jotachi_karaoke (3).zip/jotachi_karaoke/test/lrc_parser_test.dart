import 'package:flutter_test/flutter_test.dart';
import 'package:jotachi_karaoke/models/lrc.dart';
import 'package:jotachi_karaoke/models/song.dart';

void main() {
  group('LrcParser', () {
    test('parsea tiempos y texto, ignora metadatos', () {
      const src = '[ar:Artista]\n[ti:Titulo]\n[00:12.50]Hola\n[01:05.123]Mundo\n';
      final l = LrcParser.parse(src);
      expect(l.length, 2);
      expect(l[0].time, const Duration(seconds: 12, milliseconds: 500));
      expect(l[0].text, 'Hola');
      expect(l[1].time, const Duration(minutes: 1, seconds: 5, milliseconds: 123));
    });

    test('varias marcas de tiempo en una línea y orden', () {
      const src = '[00:30.00][00:10.00]Estribillo\n[00:20.00]Verso';
      final l = LrcParser.parse(src);
      expect(l.map((e) => e.text).toList(), ['Estribillo', 'Verso', 'Estribillo']);
    });

    test('aplica offset', () {
      final l = LrcParser.parse('[offset:500]\n[00:01.00]X');
      expect(l.single.time, const Duration(milliseconds: 1500));
    });

    test('currentIndex', () {
      final l = LrcParser.parse('[00:05.00]a\n[00:10.00]b\n[00:15.00]c');
      expect(LrcParser.currentIndex(l, const Duration(seconds: 1)), -1);
      expect(LrcParser.currentIndex(l, const Duration(seconds: 5)), 0);
      expect(LrcParser.currentIndex(l, const Duration(seconds: 12)), 1);
      expect(LrcParser.currentIndex(l, const Duration(seconds: 99)), 2);
    });
  });

  group('Song', () {
    test('serializa y un "processing" guardado vuelve a "none"', () {
      final s = Song(
        id: '1',
        title: 'T',
        originalPath: '/a.mp3',
        status: SeparationStatus.processing,
      );
      final back = Song.fromJson(s.toJson());
      expect(back.status, SeparationStatus.none);
      expect(back.title, 'T');
    });
  });
}
