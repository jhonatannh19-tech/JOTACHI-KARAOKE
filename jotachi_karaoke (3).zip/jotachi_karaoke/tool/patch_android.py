"""Tras `flutter create`, aplica permisos y minSdk que la app necesita."""
import pathlib
import re

root = pathlib.Path("android/app")
manifest = root / "src/main/AndroidManifest.xml"
m = manifest.read_text()
perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
"""
if "RECORD_AUDIO" not in m:
    m = m.replace("<application", perms + "    <application", 1)
if "usesCleartextTraffic" not in m:
    m = m.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
manifest.write_text(m)

for name in ("build.gradle.kts", "build.gradle"):
    g = root / name
    if g.exists():
        t = g.read_text()
        t = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 23", t)
        t = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 23", t)
        g.write_text(t)
print("Android parcheado")
