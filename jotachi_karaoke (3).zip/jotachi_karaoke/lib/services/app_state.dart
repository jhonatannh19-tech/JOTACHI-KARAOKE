import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/song.dart';
import 'ai_lyrics_service.dart';
import 'lyrics_service.dart';
import 'separation/local_separation_service.dart';
import 'separation/remote_separation_service.dart';
import 'separation/separation_service.dart';

class AppState extends ChangeNotifier {
  final List<Song> songs = [];
  String serverUrl = '';
  String apiKey = '';

  late SharedPreferences _prefs;
  late Directory _root;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final docs = await getApplicationDocumentsDirectory();
    _root = Directory(p.join(docs.path, 'songs'));
    await _root.create(recursive: true);
    serverUrl = _prefs.getString('serverUrl') ?? '';
    apiKey = _prefs.getString('apiKey') ?? '';
    final raw = _prefs.getString('library');
    if (raw != null) {
      for (final j in jsonDecode(raw) as List) {
        final s = Song.fromJson(j as Map<String, dynamic>);
        if (File(s.originalPath).existsSync()) songs.add(s);
      }
    }
  }

  Future<void> _save() => _prefs.setString(
      'library', jsonEncode(songs.map((s) => s.toJson()).toList()));

  Future<void> saveSettings(String url, String key) async {
    var u = url.trim();
    if (u.isNotEmpty && !u.startsWith('http://') && !u.startsWith('https://')) {
      u = 'https://$u';
    }
    serverUrl = u;
    apiKey = key.trim();
    await _prefs.setString('serverUrl', serverUrl);
    await _prefs.setString('apiKey', apiKey);
    notifyListeners();
  }

  /// Importa canciones del teléfono (se copian a la carpeta de la app).
  Future<int> importSongs() async {
    final res = await FilePicker.platform
        .pickFiles(type: FileType.audio, allowMultiple: true);
    if (res == null) return 0;
    var n = 0;
    for (final f in res.files) {
      final src = f.path;
      if (src == null) continue;
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final dir = Directory(p.join(_root.path, id));
      await dir.create(recursive: true);
      final dest = await File(src).copy(p.join(dir.path, p.basename(src)));
      songs.add(Song(
        id: id,
        title: p.basenameWithoutExtension(src),
        originalPath: dest.path,
      ));
      n++;
    }
    await _save();
    notifyListeners();
    return n;
  }

  Future<void> removeSong(Song s) async {
    songs.remove(s);
    final dir = Directory(p.join(_root.path, s.id));
    if (await dir.exists()) await dir.delete(recursive: true);
    await _save();
    notifyListeners();
  }

  Future<void> updateSong(Song s, {String? title, String? artist}) async {
    if (title != null) s.title = title;
    if (artist != null) s.artist = artist;
    await _save();
    notifyListeners();
  }

  /// Elige el motor: local si está disponible; si no, el servidor.
  Future<SeparationService?> _pickEngine() async {
    final local = LocalSeparationService();
    if (await local.isAvailable()) return local;
    final remote = RemoteSeparationService(serverUrl, apiKey: apiKey);
    if (await remote.isAvailable()) return remote;
    return null;
  }

  Future<void> separate(Song s) async {
    final engine = await _pickEngine();
    if (engine == null) {
      s.status = SeparationStatus.failed;
      s.error = 'Sin motor disponible: la separación local aún no existe y '
          'no se pudo contactar al servidor. Revisa Ajustes.';
      notifyListeners();
      return;
    }
    s.status = SeparationStatus.processing;
    s.progress = 0;
    s.error = null;
    notifyListeners();
    try {
      final out = p.join(_root.path, s.id, 'stems');
      final r = await engine.separate(s.originalPath, out, onProgress: (v) {
        s.progress = v;
        notifyListeners();
      });
      s.instrumentalPath = r.instrumentalPath;
      s.vocalsPath = r.vocalsPath;
      s.status = SeparationStatus.done;
    } catch (e) {
      s.status = SeparationStatus.failed;
      s.error = e.toString();
    }
    await _save();
    notifyListeners();
  }

  /// Copia un archivo .lrc elegido por el usuario.
  Future<bool> attachLrcFromPicker(Song s) async {
    final res = await FilePicker.platform.pickFiles(type: FileType.any);
    final src = res?.files.single.path;
    if (src == null) return false;
    final dest = p.join(_root.path, s.id, 'lyrics.lrc');
    await File(src).copy(dest);
    s.lrcPath = dest;
    await _save();
    notifyListeners();
    return true;
  }

  /// Descarga la letra sincronizada de LRCLIB. Devuelve true si la encontró.
  Future<bool> fetchLyricsOnline(Song s, {int? durationSec}) async {
    final lrc = await LyricsService.fetchSyncedLrc(s.title, s.artist,
        durationSec: durationSec);
    if (lrc == null) return false;
    final dest = p.join(_root.path, s.id, 'lyrics.lrc');
    await File(dest).writeAsString(lrc);
    s.lrcPath = dest;
    await _save();
    notifyListeners();
    return true;
  }

  /// Genera la letra con tiempos usando IA en el servidor. Se envía la pista de
  /// voz si existe (más precisa); si no, el audio original.
  /// Devuelve el texto LRC o null si la IA no detectó letra.
  Future<String?> generateLyricsAI(Song s) async {
    final voc = s.vocalsPath;
    final audio = (voc != null && File(voc).existsSync()) ? voc : s.originalPath;
    final ai = AiLyricsService(serverUrl, apiKey: apiKey);
    final lrc = await ai.transcribe(audio);
    if (lrc.trim().isEmpty) return null;
    final dest = p.join(_root.path, s.id, 'lyrics.lrc');
    await File(dest).writeAsString(lrc);
    s.lrcPath = dest;
    await _save();
    notifyListeners();
    return lrc;
  }

  /// Ajusta la sincronía de la letra de una canción (en milisegundos).
  Future<void> setLyricsOffset(Song s, int ms) async {
    s.lyricsOffsetMs = ms;
    await _save();
    notifyListeners();
  }
}
