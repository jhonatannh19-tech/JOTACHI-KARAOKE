import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

class RecorderService {
  final AudioRecorder _rec = AudioRecorder();
  String? _currentPath;

  Future<bool> hasPermission() => _rec.hasPermission();

  Future<bool> isRecording() => _rec.isRecording();

  /// Empieza a grabar la voz del usuario. Devuelve la ruta destino.
  Future<String?> start(String songId) async {
    if (!await _rec.hasPermission()) return null;
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'recordings', songId));
    await dir.create(recursive: true);
    final path = p.join(
        dir.path, 'take_${DateTime.now().millisecondsSinceEpoch}.m4a');
    await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
    _currentPath = path;
    return path;
  }

  Future<String?> stop() async {
    final r = await _rec.stop();
    final path = r ?? _currentPath;
    _currentPath = null;
    return path;
  }

  Future<List<File>> listTakes(String songId) async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'recordings', songId));
    if (!await dir.exists()) return [];
    final files = dir.listSync().whereType<File>().toList()
      ..sort((a, b) => b.path.compareTo(a.path));
    return files;
  }

  Future<void> dispose() => _rec.dispose();
}
