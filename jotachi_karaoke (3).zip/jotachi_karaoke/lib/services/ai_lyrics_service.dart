import 'dart:convert';

import 'package:http/http.dart' as http;

/// Genera la letra con tiempos (formato LRC) en el servidor, usando IA
/// (Whisper) sobre el audio que se le envíe (idealmente solo la voz).
class AiLyricsService {
  AiLyricsService(this.baseUrl, {this.apiKey = ''});

  final String baseUrl;
  final String apiKey;

  Map<String, String> get _headers =>
      apiKey.isEmpty ? {} : {'X-API-Key': apiKey};

  Uri _u(String path, [Map<String, String>? query]) {
    final base = baseUrl.replaceAll(RegExp(r'/+$'), '');
    return Uri.parse('$base$path').replace(queryParameters: query);
  }

  /// Devuelve el texto LRC (puede venir vacío si no se detectó voz).
  Future<String> transcribe(String audioPath, {String language = ''}) async {
    final req = http.MultipartRequest(
        'POST', _u('/lyrics', language.isEmpty ? null : {'language': language}))
      ..headers.addAll(_headers)
      ..files.add(await http.MultipartFile.fromPath('file', audioPath));
    final up = await http.Response.fromStream(await req.send());
    if (up.statusCode == 404) {
      throw Exception('El servidor no tiene la función de letras: '
          'actualiza el servidor (vuelve a ejecutar el cuaderno de Colab).');
    }
    if (up.statusCode != 200) {
      throw Exception('Error al subir (${up.statusCode}): ${up.body}');
    }
    final id = (jsonDecode(up.body) as Map<String, dynamic>)['id'] as String;

    final deadline = DateTime.now().add(const Duration(minutes: 20));
    while (true) {
      if (DateTime.now().isAfter(deadline)) {
        throw Exception('Tiempo de espera agotado.');
      }
      await Future.delayed(const Duration(seconds: 4));
      final r = await http.get(_u('/lyrics/$id'), headers: _headers);
      if (r.statusCode != 200) {
        throw Exception('Error de estado (${r.statusCode})');
      }
      final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      final status = j['status'] as String;
      if (status == 'failed') {
        throw Exception(j['error'] ?? 'Falló el servidor');
      }
      if (status == 'done') return (j['lrc'] as String?) ?? '';
    }
  }
}
