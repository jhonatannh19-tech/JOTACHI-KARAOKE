import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../models/lrc.dart';

class LyricsService {
  static Future<List<LrcLine>> loadFromFile(String path) async {
    final text = await File(path).readAsString();
    return LrcParser.parse(text);
  }

  /// Limpia nombres de archivo tipo "01 - Artista - Canción (Official Video) [HD]".
  static String _clean(String s) {
    return s
        .replaceAll('_', ' ')
        .replaceAll(RegExp(r'[\(\[][^\)\]]*[\)\]]'), ' ')
        .replaceAll(RegExp(r'^\s*\d{1,3}\s*[-.)]\s*'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  /// Devuelve [título, artista] limpios. Si no hay artista y el título es
  /// "Artista - Canción", lo separa.
  static List<String> titleAndArtist(String title, String artist) {
    var t = _clean(title);
    var a = _clean(artist);
    if (a.isEmpty) {
      final i = t.indexOf(' - ');
      if (i > 0) {
        a = t.substring(0, i).trim();
        t = t.substring(i + 3).trim();
      }
    }
    return [t, a];
  }

  /// Busca letra sincronizada en LRCLIB (https://lrclib.net). Requiere internet.
  /// Si se conoce la duración, elige el resultado cuya duración más se parece
  /// (así se evita una versión con otro ritmo). Devuelve el texto LRC o null.
  static Future<String?> fetchSyncedLrc(
    String title,
    String artist, {
    int? durationSec,
  }) async {
    final na = titleAndArtist(title, artist);
    final t = na[0];
    final a = na[1];
    if (t.isEmpty) return null;

    final queries = <Map<String, String>>[];
    if (a.isNotEmpty) queries.add({'track_name': t, 'artist_name': a});
    queries.add({'q': a.isEmpty ? t : '$a $t'});
    queries.add({'track_name': t});

    for (final params in queries) {
      final found = await _search(params, durationSec);
      if (found != null) return found;
    }
    return null;
  }

  static Future<String?> _search(
      Map<String, String> params, int? durationSec) async {
    final uri = Uri.https('lrclib.net', '/api/search', params);
    final r = await http
        .get(uri, headers: {'User-Agent': 'JotachiKaraoke/0.2'})
        .timeout(const Duration(seconds: 12));
    if (r.statusCode != 200) return null;
    final list = jsonDecode(utf8.decode(r.bodyBytes));
    if (list is! List) return null;

    String? best;
    num bestDiff = double.infinity;
    for (final item in list) {
      if (item is! Map) continue;
      final synced = item['syncedLyrics'];
      if (synced is! String || synced.trim().isEmpty) continue;
      if (durationSec == null) return synced;
      final d = item['duration'];
      final num diff = d is num ? (d - durationSec).abs() : 9999;
      if (diff < bestDiff) {
        bestDiff = diff;
        best = synced;
      }
    }
    // Más de 15 s de diferencia suele ser otra versión: mejor no usarla.
    return bestDiff <= 15 ? best : null;
  }
}
