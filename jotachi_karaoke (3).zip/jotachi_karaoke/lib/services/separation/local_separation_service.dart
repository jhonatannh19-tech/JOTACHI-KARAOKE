import 'separation_service.dart';

/// Separación EN EL TELÉFONO (sin internet).
///
/// ESTADO: NO IMPLEMENTADA. Requiere un modelo ONNX/TFLite de separación
/// (p. ej. un Spleeter/Demucs cuantizado), su runtime nativo y decodificación
/// y mezcla de audio a PCM. Nada de eso existe todavía en este proyecto.
/// Por eso [isAvailable] devuelve false y la app usa el servidor.
class LocalSeparationService implements SeparationService {
  @override
  String get name => 'Local (sin internet)';

  @override
  Future<bool> isAvailable() async => false;

  @override
  Future<SeparationResult> separate(
    String inputPath,
    String outDir, {
    void Function(double progress)? onProgress,
  }) {
    throw UnsupportedError('La separación local aún no está implementada.');
  }
}
