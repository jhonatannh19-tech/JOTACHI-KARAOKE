import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;

import 'separation_service.dart';

/// Separación en un servidor propio (ver carpeta /server).
class RemoteSeparationService implements SeparationService {
  RemoteSeparationService(this.baseUrl, {this.apiKey = ''});

  final String baseUrl;
  final String apiKey;

  @override
  String get name => 'Servidor';

  Map<String, String> get _headers =>
      apiKey.isEmpty ? {} : {'X-API-Key': apiKey};

  Uri _u(String path) =>
      Uri.parse('${baseUrl.replaceAll(RegExp(r'/+$'), '')}$path');

  @override
  Future<bool> isAvailable() async {
    if (baseUrl.trim().isEmpty) return false;
    try {
      final r = await http
          .get(_u('/health'), headers: _headers)
          .timeout(const Duration(seconds: 5));
      return r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<SeparationResult> separate(
    String inputPath,
    String outDir, {
    void Function(double progress)? onProgress,
  }) async {
    // 1) subir
    final req = http.MultipartRequest('POST', _u('/jobs'))
      ..headers.addAll(_headers)
      ..files.add(await http.MultipartFile.fromPath('file', inputPath));
    final up = await http.Response.fromStream(await req.send());
    if (up.statusCode != 200) {
      throw Exception('Error al subir (${up.statusCode}): ${up.body}');
    }
    final id = (jsonDecode(up.body) as Map<String, dynamic>)['id'] as String;
    onProgress?.call(0.1);

    // 2) esperar (la separación en CPU puede tardar varios minutos)
    final deadline = DateTime.now().add(const Duration(minutes: 30));
    while (true) {
      if (DateTime.now().isAfter(deadline)) {
        throw Exception('Tiempo de espera agotado.');
      }
      await Future.delayed(const Duration(seconds: 3));
      final r = await http.get(_u('/jobs/$id'), headers: _headers);
      if (r.statusCode != 200) {
        throw Exception('Error de estado (${r.statusCode})');
      }
      final j = jsonDecode(r.body) as Map<String, dynamic>;
      final status = j['status'] as String;
      if (status == 'failed') {
        throw Exception(j['error'] ?? 'Falló el servidor');
      }
      if (status == 'done') break;
      onProgress?.call(0.1 + 0.7 * ((j['progress'] as num?)?.toDouble() ?? 0));
    }

    // 3) descargar
    await Directory(outDir).create(recursive: true);
    final inst = await _download(
        '/jobs/$id/instrumental', p.join(outDir, 'instrumental.wav'));
    onProgress?.call(0.9);
    final voc =
        await _download('/jobs/$id/vocals', p.join(outDir, 'vocals.wav'));
    onProgress?.call(1);
    return SeparationResult(instrumentalPath: inst, vocalsPath: voc);
  }

  Future<String> _download(String path, String dest) async {
    final client = http.Client();
    try {
      final res = await client
          .send(http.Request('GET', _u(path))..headers.addAll(_headers));
      if (res.statusCode != 200) {
        throw Exception('Descarga falló (${res.statusCode})');
      }
      final sink = File(dest).openWrite();
      await res.stream.pipe(sink);
      return dest;
    } finally {
      client.close();
    }
  }
}
