class SeparationResult {
  const SeparationResult({required this.instrumentalPath, this.vocalsPath});
  final String instrumentalPath;
  final String? vocalsPath;
}

abstract class SeparationService {
  String get name;

  /// Si este motor puede usarse ahora mismo.
  Future<bool> isAvailable();

  Future<SeparationResult> separate(
    String inputPath,
    String outDir, {
    void Function(double progress)? onProgress,
  });
}
