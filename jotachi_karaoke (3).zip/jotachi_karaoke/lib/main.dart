import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/home_screen.dart';
import 'services/app_state.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.init();
  runApp(ChangeNotifierProvider.value(value: state, child: const JotachiApp()));
}

class JotachiApp extends StatelessWidget {
  const JotachiApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'JOTACHI PROFESSIONAL KARAOKE',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const HomeScreen(),
      );
}
