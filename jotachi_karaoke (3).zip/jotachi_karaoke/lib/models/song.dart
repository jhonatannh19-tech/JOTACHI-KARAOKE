enum SeparationStatus { none, processing, done, failed }

class Song {
  Song({
    required this.id,
    required this.title,
    required this.originalPath,
    this.artist = '',
    this.instrumentalPath,
    this.vocalsPath,
    this.lrcPath,
    this.lyricsOffsetMs = 0,
    this.status = SeparationStatus.none,
    this.progress = 0,
    this.error,
  });

  final String id;
  String title;
  String artist;
  final String originalPath;
  String? instrumentalPath;
  String? vocalsPath;
  String? lrcPath;
  int lyricsOffsetMs; // + adelanta la letra, - la atrasa
  SeparationStatus status;
  double progress; // 0..1, solo en memoria
  String? error; // solo en memoria

  bool get hasInstrumental => instrumentalPath != null;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist': artist,
        'originalPath': originalPath,
        'instrumentalPath': instrumentalPath,
        'vocalsPath': vocalsPath,
        'lrcPath': lrcPath,
        'lyricsOffsetMs': lyricsOffsetMs,
        'status': status.name,
      };

  factory Song.fromJson(Map<String, dynamic> j) {
    final st = SeparationStatus.values.firstWhere(
      (s) => s.name == j['status'],
      orElse: () => SeparationStatus.none,
    );
    return Song(
      id: j['id'] as String,
      title: j['title'] as String,
      artist: (j['artist'] as String?) ?? '',
      originalPath: j['originalPath'] as String,
      instrumentalPath: j['instrumentalPath'] as String?,
      vocalsPath: j['vocalsPath'] as String?,
      lrcPath: j['lrcPath'] as String?,
      lyricsOffsetMs: (j['lyricsOffsetMs'] as num?)?.toInt() ?? 0,
      // Un proceso interrumpido no se puede reanudar.
      status: st == SeparationStatus.processing ? SeparationStatus.none : st,
    );
  }
}
