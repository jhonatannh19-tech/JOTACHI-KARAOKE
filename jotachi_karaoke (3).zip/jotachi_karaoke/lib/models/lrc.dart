class LrcLine {
  const LrcLine(this.time, this.text);
  final Duration time;
  final String text;
}

/// Parser de letras sincronizadas en formato LRC.
class LrcParser {
  static final _tag = RegExp(r'\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]');
  static final _offset =
      RegExp(r'^\[offset:\s*(-?\d+)\s*\]', caseSensitive: false);

  static List<LrcLine> parse(String content) {
    final lines = <LrcLine>[];
    var offsetMs = 0;
    for (final raw in content.split(RegExp(r'\r?\n'))) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      final off = _offset.firstMatch(line);
      if (off != null) {
        offsetMs = int.parse(off.group(1)!);
        continue;
      }
      final matches = _tag.allMatches(line).toList();
      if (matches.isEmpty) continue; // metadatos [ar:], [ti:], etc.
      final text = line.substring(matches.last.end).trim();
      for (final m in matches) {
        final min = int.parse(m.group(1)!);
        final sec = int.parse(m.group(2)!);
        final frac = m.group(3);
        var ms = 0;
        if (frac != null) {
          ms = frac.length == 1
              ? int.parse(frac) * 100
              : frac.length == 2
                  ? int.parse(frac) * 10
                  : int.parse(frac);
        }
        final total = (min * 60 + sec) * 1000 + ms + offsetMs;
        lines.add(LrcLine(Duration(milliseconds: total < 0 ? 0 : total), text));
      }
    }
    lines.sort((a, b) => a.time.compareTo(b.time));
    return lines;
  }

  /// Índice de la línea activa para [position], o -1 si aún no empieza.
  static int currentIndex(List<LrcLine> lines, Duration position) {
    var lo = 0, hi = lines.length - 1, ans = -1;
    while (lo <= hi) {
      final mid = (lo + hi) >> 1;
      if (lines[mid].time <= position) {
        ans = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return ans;
  }
}
