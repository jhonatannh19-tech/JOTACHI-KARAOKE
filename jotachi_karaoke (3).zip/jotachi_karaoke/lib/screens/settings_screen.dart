import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';
import '../services/separation/remote_separation_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _url;
  late final TextEditingController _key;
  String? _test;

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>();
    _url = TextEditingController(text: s.serverUrl);
    _key = TextEditingController(text: s.apiKey);
  }

  @override
  void dispose() {
    _url.dispose();
    _key.dispose();
    super.dispose();
  }

  Future<void> _save({bool test = false}) async {
    await context.read<AppState>().saveSettings(_url.text, _key.text);
    if (!test) return;
    setState(() => _test = 'Probando…');
    final ok = await RemoteSeparationService(_url.text.trim(),
            apiKey: _key.text.trim())
        .isAvailable();
    if (mounted) setState(() => _test = ok ? 'Conectado ✔' : 'Sin conexión ✖');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Ajustes')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Servidor de separación de voz',
                style: TextStyle(
                    color: JColors.gold,
                    fontWeight: FontWeight.bold,
                    fontSize: 16)),
            const SizedBox(height: 8),
            const Text(
              'La separación local (sin internet) aún no está implementada. '
              'La app usa un servidor con IA para quitar la voz y generar letras: '
              'abre el cuaderno JOTACHI_Servidor en Google Colab, ejecútalo y '
              'pega aquí la URL y la clave que muestre al final.',
              style: TextStyle(color: JColors.textDim),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _url,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                  labelText: 'URL del servidor',
                  hintText: 'https://xxxx.trycloudflare.com',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _key,
              obscureText: true,
              decoration: const InputDecoration(
                  labelText: 'Clave API',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            Row(children: [
              FilledButton(
                  onPressed: () => _save(test: true),
                  child: const Text('Guardar y probar')),
              const SizedBox(width: 12),
              Text(_test ?? ''),
            ]),
          ],
        ),
      );
}
