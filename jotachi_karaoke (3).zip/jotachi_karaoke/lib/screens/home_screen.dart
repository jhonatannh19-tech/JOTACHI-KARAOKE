import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/song.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import 'player_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: ShaderMask(
          shaderCallback: (r) => const LinearGradient(
            colors: [JColors.gold, JColors.blue],
          ).createShader(r),
          child: const Text('JOTACHI KARAOKE',
              style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 2)),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: JColors.blue),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: state.songs.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Tu biblioteca está vacía.\nToca + para importar canciones del teléfono.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: JColors.textDim, fontSize: 16),
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: state.songs.length,
              itemBuilder: (_, i) => _SongTile(song: state.songs[i]),
            ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('Importar'),
        onPressed: () async {
          final n = await context.read<AppState>().importSongs();
          if (context.mounted && n > 0) {
            ScaffoldMessenger.of(context)
                .showSnackBar(SnackBar(content: Text('$n canción(es) importada(s)')));
          }
        },
      ),
    );
  }
}

class _SongTile extends StatelessWidget {
  const _SongTile({required this.song});
  final Song song;

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final Widget trailing;
    switch (song.status) {
      case SeparationStatus.processing:
        trailing = SizedBox(
          width: 28,
          height: 28,
          child: CircularProgressIndicator(
              value: song.progress > 0 ? song.progress : null,
              color: JColors.blue,
              strokeWidth: 3),
        );
      case SeparationStatus.done:
        trailing = const Icon(Icons.check_circle, color: JColors.gold);
      default:
        trailing = IconButton(
          tooltip: 'Quitar voz (IA)',
          icon: const Icon(Icons.auto_fix_high, color: JColors.purple),
          onPressed: () => state.separate(song),
        );
    }
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: JColors.purple,
          child: Icon(Icons.music_note, color: Colors.white),
        ),
        title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text(
          song.status == SeparationStatus.failed
              ? (song.error ?? 'Error')
              : song.hasInstrumental
                  ? 'Instrumental listo'
                  : 'Solo original',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
              color: song.status == SeparationStatus.failed
                  ? Colors.redAccent
                  : JColors.textDim),
        ),
        trailing: trailing,
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => PlayerScreen(song: song))),
        onLongPress: () async {
          final ok = await showDialog<bool>(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('Eliminar canción'),
              content: Text('¿Eliminar "${song.title}" de la biblioteca?'),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancelar')),
                TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Eliminar')),
              ],
            ),
          );
          if (ok == true) await state.removeSong(song);
        },
      ),
    );
  }
}
