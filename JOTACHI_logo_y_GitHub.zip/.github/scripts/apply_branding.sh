#!/usr/bin/env bash
set -euo pipefail
# Aplica el logo JOTACHI como icono Android y pantalla de inicio.
test -f assets/jotachi_logo.png || { echo "No se encontró assets/jotachi_logo.png"; exit 1; }
mkdir -p android/app/src/main/res/drawable-nodpi
cp assets/jotachi_logo.png android/app/src/main/res/drawable-nodpi/jotachi_logo.png
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "android/app/src/main/res/mipmap-${density}"
  cp assets/jotachi_logo.png "android/app/src/main/res/mipmap-${density}/ic_launcher.png"
done
cat > android/app/src/main/res/drawable/launch_background.xml <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="#090b35" />
    <item>
        <bitmap
            android:gravity="center"
            android:src="@drawable/jotachi_logo" />
    </item>
</layer-list>
XML
echo "Logo JOTACHI aplicado al icono y a la pantalla de inicio."
