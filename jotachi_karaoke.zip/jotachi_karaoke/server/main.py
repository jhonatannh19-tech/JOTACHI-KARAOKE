"""Servidor de separación de voz para JOTACHI KARAOKE (Demucs).

Uso:  uvicorn main:app --host 0.0.0.0 --port 8000
Variable opcional API_KEY: si se define, la app debe enviarla en X-API-Key.
"""
import os
import pathlib
import shutil
import subprocess
import sys
import uuid

from fastapi import BackgroundTasks, Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse

BASE = pathlib.Path(os.environ.get("JOBS_DIR", "jobs"))
BASE.mkdir(parents=True, exist_ok=True)
API_KEY = os.environ.get("API_KEY", "")
JOBS: dict = {}

app = FastAPI(title="Jotachi separation server")


def auth(x_api_key: str = Header(default="")):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="API key inválida")


def run_job(job_id: str, src: pathlib.Path):
    out = BASE / job_id / "out"
    try:
        JOBS[job_id].update(status="processing", progress=0.05)
        cmd = [sys.executable, "-m", "demucs", "--two-stems=vocals", "-o", str(out), str(src)]
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        inst = next(out.rglob("no_vocals.wav"))
        voc = next(out.rglob("vocals.wav"))
        shutil.copy(inst, BASE / job_id / "instrumental.wav")
        shutil.copy(voc, BASE / job_id / "vocals.wav")
        JOBS[job_id].update(status="done", progress=1.0)
    except subprocess.CalledProcessError as e:
        JOBS[job_id].update(status="failed", error=(e.stderr or str(e))[-500:])
    except Exception as e:  # noqa: BLE001
        JOBS[job_id].update(status="failed", error=str(e))


@app.get("/health")
def health(_: None = Depends(auth)):
    return {"ok": True}


@app.post("/jobs")
async def create_job(bg: BackgroundTasks, file: UploadFile = File(...), _: None = Depends(auth)):
    job_id = uuid.uuid4().hex
    folder = BASE / job_id
    folder.mkdir(parents=True)
    suffix = pathlib.Path(file.filename or "audio").suffix or ".mp3"
    src = folder / f"input{suffix}"
    with src.open("wb") as f:
        shutil.copyfileobj(file.file, f)
    JOBS[job_id] = {"status": "queued", "progress": 0.0}
    bg.add_task(run_job, job_id, src)
    return {"id": job_id}


@app.get("/jobs/{job_id}")
def job_status(job_id: str, _: None = Depends(auth)):
    if job_id not in JOBS:
        raise HTTPException(404, "No existe")
    return JOBS[job_id]


def _stem(job_id: str, name: str):
    p = BASE / job_id / f"{name}.wav"
    if job_id not in JOBS or not p.exists():
        raise HTTPException(404, "Aún no disponible")
    return FileResponse(p, media_type="audio/wav", filename=f"{name}.wav")


@app.get("/jobs/{job_id}/instrumental")
def instrumental(job_id: str, _: None = Depends(auth)):
    return _stem(job_id, "instrumental")


@app.get("/jobs/{job_id}/vocals")
def vocals(job_id: str, _: None = Depends(auth)):
    return _stem(job_id, "vocals")
