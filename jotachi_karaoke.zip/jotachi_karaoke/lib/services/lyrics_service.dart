import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../models/lrc.dart';

class LyricsService {
  static Future<List<LrcLine>> loadFromFile(String path) async {
    final text = await File(path).readAsString();
    return LrcParser.parse(text);
  }

  /// Busca letra sincronizada en LRCLIB (https://lrclib.net). Requiere internet.
  /// Devuelve el texto LRC o null si no hay letra sincronizada.
  static Future<String?> fetchSyncedLrc(String title, String artist) async {
    final uri = Uri.https('lrclib.net', '/api/search', {
      'track_name': title,
      if (artist.isNotEmpty) 'artist_name': artist,
    });
    final r = await http.get(uri).timeout(const Duration(seconds: 10));
    if (r.statusCode != 200) return null;
    final list = jsonDecode(utf8.decode(r.bodyBytes));
    if (list is! List) return null;
    for (final item in list) {
      final synced = (item as Map<String, dynamic>)['syncedLyrics'];
      if (synced is String && synced.trim().isNotEmpty) return synced;
    }
    return null;
  }
}
