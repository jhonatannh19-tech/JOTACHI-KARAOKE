import 'package:flutter/material.dart';

class JColors {
  static const black = Color(0xFF0A0A0F);
  static const surface = Color(0xFF15121F);
  static const purple = Color(0xFF7B2FF7);
  static const blue = Color(0xFF0AA5FF);
  static const gold = Color(0xFFFFC83D);
  static const textDim = Color(0xFF9A96AE);
}

ThemeData buildTheme() {
  const scheme = ColorScheme.dark(
    primary: JColors.purple,
    secondary: JColors.blue,
    tertiary: JColors.gold,
    surface: JColors.surface,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: JColors.black,
    appBarTheme: const AppBarTheme(
      backgroundColor: JColors.black,
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    cardTheme: CardTheme(
      color: JColors.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: JColors.gold,
      foregroundColor: Colors.black,
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor: JColors.blue,
      thumbColor: JColors.gold,
    ),
  );
}
