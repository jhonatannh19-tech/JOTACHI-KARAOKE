import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';

import '../models/lrc.dart';
import '../models/song.dart';
import '../services/app_state.dart';
import '../services/lyrics_service.dart';
import '../services/recorder_service.dart';
import '../theme/app_theme.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.song});
  final Song song;
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final _player = AudioPlayer();
  final _takePlayer = AudioPlayer();
  final _recorder = RecorderService();
  final _scroll = ScrollController();

  List<LrcLine> _lyrics = [];
  bool _useInstrumental = true;
  bool _recording = false;
  int _line = -1;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;
  StreamSubscription<Duration>? _posSub;
  static const _lineH = 56.0;

  Song get song => widget.song;
  String get _path => (_useInstrumental && song.hasInstrumental)
      ? song.instrumentalPath!
      : song.originalPath;

  @override
  void initState() {
    super.initState();
    _useInstrumental = song.hasInstrumental;
    _load();
    _loadLyrics();
    _posSub = _player.positionStream.listen((p) {
      final idx = LrcParser.currentIndex(_lyrics, p);
      if (!mounted) return;
      setState(() {
        _pos = p;
        if (idx != _line) {
          _line = idx;
          _scrollToLine();
        }
      });
    });
    _player.durationStream.listen((d) {
      if (d != null && mounted) setState(() => _dur = d);
    });
  }

  Future<void> _load({Duration? at}) async {
    try {
      await _player.setFilePath(_path);
      if (at != null) await _player.seek(at);
    } catch (e) {
      _snack('No se pudo abrir el audio: $e');
    }
  }

  Future<void> _loadLyrics() async {
    final path = song.lrcPath;
    if (path == null || !File(path).existsSync()) return;
    final l = await LyricsService.loadFromFile(path);
    if (mounted) setState(() => _lyrics = l);
  }

  void _scrollToLine() {
    if (!_scroll.hasClients || _line < 0) return;
    final target = _line * _lineH - _scroll.position.viewportDimension / 2 + _lineH / 2;
    _scroll.animateTo(
      target.clamp(0, _scroll.position.maxScrollExtent),
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _toggleSource(bool inst) async {
    final at = _player.position;
    final wasPlaying = _player.playing;
    setState(() => _useInstrumental = inst);
    await _load(at: at);
    if (wasPlaying) _player.play();
  }

  Future<void> _toggleRecord() async {
    if (_recording) {
      final path = await _recorder.stop();
      await _player.pause();
      setState(() => _recording = false);
      _snack(path == null ? 'No se guardó la grabación' : 'Toma guardada');
    } else {
      final path = await _recorder.start(song.id);
      if (path == null) {
        _snack('Permiso de micrófono denegado');
        return;
      }
      await _player.seek(Duration.zero);
      _player.play();
      setState(() => _recording = true);
    }
  }

  Future<void> _fetchLyrics() async {
    final state = context.read<AppState>();
    try {
      final ok = await state.fetchLyricsOnline(song);
      _snack(ok ? 'Letra descargada' : 'No se encontró letra sincronizada');
      if (ok) await _loadLyrics();
    } catch (e) {
      _snack('Sin conexión o error: $e');
    }
  }

  Future<void> _pickLrc() async {
    final state = context.read<AppState>();
    if (await state.attachLrcFromPicker(song)) await _loadLyrics();
  }

  Future<void> _showTakes() async {
    final takes = await _recorder.listTakes(song.id);
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: JColors.surface,
      builder: (_) => takes.isEmpty
          ? const SizedBox(
              height: 120, child: Center(child: Text('Aún no hay tomas')))
          : ListView(
              children: [
                for (final f in takes)
                  ListTile(
                    leading: const Icon(Icons.play_arrow, color: JColors.blue),
                    title: Text(f.uri.pathSegments.last),
                    onTap: () async {
                      await _takePlayer.setFilePath(f.path);
                      _takePlayer.play();
                    },
                  ),
              ],
            ),
    );
  }

  String _fmt(Duration d) =>
      '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  void dispose() {
    _posSub?.cancel();
    _player.dispose();
    _takePlayer.dispose();
    _recorder.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'online') _fetchLyrics();
              if (v == 'file') _pickLrc();
              if (v == 'takes') _showTakes();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'online', child: Text('Buscar letra online')),
              PopupMenuItem(value: 'file', child: Text('Cargar archivo .lrc')),
              PopupMenuItem(value: 'takes', child: Text('Mis grabaciones')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _lyricsView()),
          if (song.hasInstrumental)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: false, label: Text('Original')),
                  ButtonSegment(value: true, label: Text('Instrumental')),
                ],
                selected: {_useInstrumental},
                onSelectionChanged: (s) => _toggleSource(s.first),
              ),
            ),
          Slider(
            value: _pos.inMilliseconds
                .clamp(0, _dur.inMilliseconds == 0 ? 1 : _dur.inMilliseconds)
                .toDouble(),
            max: (_dur.inMilliseconds == 0 ? 1 : _dur.inMilliseconds).toDouble(),
            onChanged: (v) => _player.seek(Duration(milliseconds: v.round())),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Text(_fmt(_pos),
                      style: const TextStyle(color: JColors.textDim))),
              Padding(
                  padding: const EdgeInsets.only(right: 20),
                  child: Text(_fmt(_dur),
                      style: const TextStyle(color: JColors.textDim))),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  iconSize: 36,
                  icon: const Icon(Icons.replay_10, color: Colors.white),
                  onPressed: () => _player
                      .seek(_player.position - const Duration(seconds: 10)),
                ),
                StreamBuilder<PlayerState>(
                  stream: _player.playerStateStream,
                  builder: (_, snap) {
                    final playing = snap.data?.playing ?? false;
                    return Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                            colors: [JColors.purple, JColors.blue]),
                      ),
                      child: IconButton(
                        iconSize: 48,
                        color: Colors.white,
                        icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                        onPressed: () =>
                            playing ? _player.pause() : _player.play(),
                      ),
                    );
                  },
                ),
                IconButton(
                  iconSize: 36,
                  icon: Icon(_recording ? Icons.stop_circle : Icons.mic,
                      color: _recording ? Colors.redAccent : JColors.gold),
                  tooltip: _recording ? 'Detener grabación' : 'Grabar mi voz',
                  onPressed: _toggleRecord,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _lyricsView() {
    if (_lyrics.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'Sin letra.\nUsa el menú ⋮ para buscarla online o cargar un archivo .lrc.',
            textAlign: TextAlign.center,
            style: TextStyle(color: JColors.textDim),
          ),
        ),
      );
    }
    return ListView.builder(
      controller: _scroll,
      itemExtent: _lineH,
      itemCount: _lyrics.length,
      itemBuilder: (_, i) {
        final active = i == _line;
        return Center(
          child: AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 200),
            style: TextStyle(
              fontSize: active ? 24 : 18,
              fontWeight: active ? FontWeight.w800 : FontWeight.w500,
              color: active ? JColors.gold : JColors.textDim,
            ),
            textAlign: TextAlign.center,
            child: Text(_lyrics[i].text.isEmpty ? '♪' : _lyrics[i].text,
                maxLines: 2, overflow: TextOverflow.ellipsis),
          ),
        );
      },
    );
  }
}
